// import React, { useState } from 'react';
// import { Link } from 'react-router-dom';
// import watch_Data from './Watch';
// import '../style/Watch.css';

// export default function ProductForm() {
//   const [searchQuery, setSearchQuery] = useState('');
//   const [filteredWatchData, setFilteredWatchData] = useState(watch_Data);

//   const handleSearchChange = (e) => {
//     setSearchQuery(e.target.value);
//   };

//   const handleSearchClick = () => {
//     const filteredData = watch_Data.filter((item) =>
//       item.title.toLowerCase().includes(searchQuery.toLowerCase())
//     );
//     setFilteredWatchData(filteredData);
//   };

//   return (
//     <div>
//       <div className='Watch_main_div'>
//         <h2 className='section-header__title show-sep text-center'>
//           Watch
//         </h2>

//         <div className='search-container text-center mb-4'>
//           <input
//             type='text'
//             placeholder='Search watches...'
//             value={searchQuery}
//             onChange={handleSearchChange}
//             className='search-input'
//           />
//           <button onClick={handleSearchClick} className='search-button'>
//             Search
//           </button>
//         </div>

//         <div className='d-flex container justify-content-around gap-2 flex-wrap Best_watch_Cart'>
//           {filteredWatchData.map((item) => (
//             <div className='Cart' key={item.id}>
//               <div className='Img-main d-flex justify-content-center align-items-center'>
//                 <Link to={`/ProductPage/${item.id}`}>
//                   <img src={item.img} alt={item.title} />
//                 </Link>
//               </div>
//               <div className='d-flex justify-content-between align-items-center p-2 title'>
//                 <h3>{item.title}</h3>
//                 <p className='mt-2'>{item.rating}</p>
//               </div>
//               <div className='p-1 ps-2'>
//                 <h4>{item.price}</h4>
//               </div>
//               <div className='ps-2 p-1 Addtocart'>
//                 <h5 className='text-dark'>Add to cart</h5>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// }



import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import watch_Data from './Watch';
import '../style/Watch.css';

export default function ProductForm() {
  const [searchQuery, setSearchQuery] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [filteredWatchData, setFilteredWatchData] = useState(watch_Data);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleMinPriceChange = (e) => {
    setMinPrice(e.target.value);
  };

  const handleMaxPriceChange = (e) => {
    setMaxPrice(e.target.value);
  };

  const handleSearchClick = () => {
    filterData();
  };

  const filterData = () => {
    let filteredData = watch_Data;

    filteredData = filteredData.filter((item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (minPrice !== '') {
      filteredData = filteredData.filter(
        (item) => Number(item.price.replace('₹', '').replace(',', '')) >= Number(minPrice)
      );
    }

    if (maxPrice !== '') {
      filteredData = filteredData.filter(
        (item) => Number(item.price.replace('₹', '').replace(',', '')) <= Number(maxPrice)
      );
    }

    setFilteredWatchData(filteredData);
  };

  return (
    <div>
      <div className='Watch_main_div'>
        <h2 className='section-header__title show-sep text-center'>
          Watch
        </h2>

        <div className='search-container text-center mb-4'>
          <input
            type='text'
            placeholder='Search watches...'
            value={searchQuery}
            onChange={handleSearchChange}
            className='search-input'
          />
          <button onClick={handleSearchClick} className='search-button'>
            Search
          </button>
        </div>

        <div className='price-filter text-center mb-4'>
          <input
            type='number'
            placeholder='Min Price'
            value={minPrice}
            onChange={handleMinPriceChange}
            className='price-input'
          />
          <input
            type='number'
            placeholder='Max Price'
            value={maxPrice}
            onChange={handleMaxPriceChange}
            className='price-input'
          />
          <button onClick={handleSearchClick} className='filter-button'>
            Filter
          </button>
        </div>

        <div className='d-flex container justify-content-around gap-2 flex-wrap Best_watch_Cart'>
          {filteredWatchData.map((item) => (
            <div className='Cart' key={item.id}>
              <div className='Img-main d-flex justify-content-center align-items-center'>
                <Link to={`/ProductPage/${item.id}`}>
                  <img src={item.img} alt={item.title} />
                </Link>
              </div>
              <div className='d-flex justify-content-between align-items-center p-2 title'>
                <h3>{item.title}</h3>
                <p className='mt-2'>{item.rating}</p>
              </div>
              <div className='p-1 ps-2'>
                <h4>{item.price}</h4>
              </div>
              <div className='ps-2 p-1 Addtocart'>
                <h5 className='text-dark'>Add to cart</h5>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
