const watch_Data = [
   
    {
        img: "https://s.alicdn.com/@sc04/kf/H3cc9a95cc0934b0e820433e503eb45b4i.jpg_300x300.jpg",
        rating: "⭐ 2.9",
        price: "₹1,299",
        title: "Crusader",
        id: 1
    },
    {
        img: "https://i.pinimg.com/236x/1a/b0/6b/1ab06bfcd56b5864ea3721184366c3e2.jpg",
        rating: "⭐ 3.8",
        price: "₹2,099",
        title: "Bluetooth calling",
        id: 2
    },
    {
        img: "https://images.glowroad.com/faceview/a9d/hh/i3j/cc/imgs/pd/1680678049511_41kS3zMlr_L._SY450_-xlgn400x400.jpg?productId=P-13918478",
        rating: "⭐ 4.9",
        price: "₹4,299",
        title: "Amoled display",
        id: 3
    },
    {
        img: "https://mir-s3-cdn-cf.behance.net/projects/404/1e9040159065851.Y3JvcCwzMTcxLDI0ODEsMTY0LDA.jpg",
        rating: "⭐ 3.2",
        price: "₹1,249",
        title: "Fire-Boltt Cobra",
        id: 4
    },
    {
        img: "https://mirrorkosmima.gr/image/cache/catalog/TIMEX/TW2R64700-Harborside-42mm-11mm-5atm-1-1000x1000h.jpg",
        rating: "⭐ 3.9",
        price: "₹899",
        title: "Outdoor series",
        id: 5
    },
    {
        img: "https://www.dhresource.com/webp/m/0x0/f2/albu/g18/M00/12/28/rBVapWEXmHyAI6v3AAhRZaqU01M638.jpg",
        rating: "⭐ 3.7",
        price: "₹999",
        title: "Grenade",
        id: 6
    }
]

export default watch_Data