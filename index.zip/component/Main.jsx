import React from 'react'
import ProductForm from './ProductForm'
import Navbar from './Navbar'
// import Filter from './PriceFilter'

export default function Main() {
    return (
        <div>
            {/* <Filter/> */}
            <Navbar />
            <ProductForm />
        </div>
    )
}
