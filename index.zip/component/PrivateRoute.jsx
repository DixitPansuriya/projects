import React from 'react'
import watch_Data from './Watch'
import { useParams } from 'react-router-dom';

export default function PrivateRoute() {
  const { id } = useParams();
  const product = watch_Data.find(item => item.id === parseInt(id));


  return (
    <div className='d-flex justify-content-center '>
      {
        <div className='d-flex align-items-center w-50 border'>
          <div className='w-50 text-center'>
            <img src={product.img} alt="" className='w-75' />
          </div>
          <div className='w-50'>
            <h1>{product.title}</h1>
            <div className='d-flex align-items-center justify-content-between w-50 gap-3'>
              <h3>{product.price}</h3>
              <h4>Add to cart</h4>
            </div>
          </div>
        </div>
      }
    </div>

  )
}
