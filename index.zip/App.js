import { Route, Routes } from 'react-router-dom';
import './App.css';
import PrivateRoute from './component/PrivateRoute';
import Main from './component/Main';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Main />} />
      </Routes>
      <Routes>
        <Route path='/ProductPage/:id' element={<PrivateRoute />} />
      </Routes>
      {/* <PrivateRoute /> */}
    </div>
  );
}

export default App;
